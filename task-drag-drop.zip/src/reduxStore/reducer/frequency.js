const initialState = [
  {
    id: "1",
    category: "year",
    title: "YEAR",
  },
  {
    id: "2",
    category: "half-year",
    title: "HALF YEAR",
  },
  {
    id: "3",
    category: "3-times-a-year",
    title: "3 TIMES A YEAR",
  },
  {
    id: "4",
    category: "quarterly",
    title: "QUARTERLY",
  },
  {
    id: "5",
    category: "6-times-a-year",
    title: "6 TIMES A YEAR",
  },
  {
    id: "6",
    category: "as-required",
    title: "AS REQUIRED",
  },
  {
    id: "7",
    category: "hallways-on-rotation",
    title: "HALLWAYS ON ROTATION ",
  },
  {
    id: "8",
    category: "na",
    title: "NA",
  },
];

export default (state = initialState) => {
  return state;
};
