import Frequency  from './frequency'
export default Frequency