import ListPeriodicals from './listPeriodicals'
export default ListPeriodicals