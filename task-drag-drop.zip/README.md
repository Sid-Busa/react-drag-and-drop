# create UI
# add redux store and neccesary data
# drag and drop feature